import numpy as np
import h5py
import math

class Mathcalculation3():
    def __init__(self, dim):
        self.dim = dim
        self.odim = 1
        # self.miu = 1
        # self.sigma = 0.15
        self.low = 0
        self.up = 2

    def __call__(self, sample):
        input_data = self.getiput(sample)
        output_data = np.zeros([np.sum(sample), self.odim])
        for i in range(sample.shape[0]):
            # print(np.sum(sample[:i]))
            x = input_data[np.sum(sample[:i]):np.sum(sample[:i+1]),:]
            output_data[np.sum(sample[:i]):np.sum(sample[:i+1]), :] = self.getoutput(x, i)
        data = np.append(input_data, output_data, axis=1)
        f = h5py.File('traindata.h5', 'w')
        f['trainXy'] = data
        f['sample'] = sample
        f.close()
        return data

    def UQ(self, count):
        # x = np.random.normal(self.miu, self.sigma, size=(count, self.dim))
        x = np.random.uniform(self.low, self.up, size=(count, self.dim))
        y = self.multical(x, 1)
        return x, y

    def getiput(self, sample):
        # return np.random.randn(np.sum(sample), self.dim) * self.sigma + self.miu
        return np.random.uniform(self.low, self.up, size=(np.sum(sample), self.dim))

    def getoutput(self, data, flag):
        return self.multical(data, flag)

    def valid(self, count):
        x_val = self.getiput(count)
        y_val = self.multical(x_val, 1)
        data = np.append(x_val, y_val, axis=1)
        return data, x_val, y_val

    def Mextract(self, data, sample, i):
        index = int(sample[i])
        if round(index / 5) <= 1:
            valid_num = 2
        else:
            valid_num = round(index / 5) * 2
        allindex = 0
        for ss in range(i + 1):
            allindex += int(sample[ss])
        data_train = data[allindex - index:allindex, :]
        np.random.shuffle(data_train)
        data_valid = data_train[0:valid_num, :]
        return data_train, data_valid

    def extract(self, data, sample):
        np.random.shuffle(data)
        index = int(np.sum(sample))
        if round(index / 10) <= 1:
            valid_num = 2
        else:
            valid_num = round(index / 10)
        data_train = data[valid_num:, :]
        data_valid = data[:valid_num, :]
        return data_train, data_valid

    def multical(self, x, flag):
        # dim = x.shape[1]
        count = x.shape[0]
        y = np.zeros([count, 1])
        if flag == 0:
            y = 0.5 * np.sin(12 * x - 4) * (6 * x - 2)**2 + 10 * (x - 0.5) - 5
        else:
            y = np.sin(12 * x - 4) * (6 * x - 2)**2
        y = y.reshape(count, 1)
        return y

    def get_all_data(self, sample):
        miu = self.miu
        sigma = self.sigma
        dim = self.dim
        count1 = sample[0]
        x1 = np.random.randn(count1, dim) * sigma + miu
        y1 = self.multical(x1, 0)
        # print(x1)

        count2 = sample[1]
        x2 = np.random.randn(count2, dim) * sigma + miu
        y2 = self.multical(x2, 1)


        XX = np.append(x1, x2, axis=0)
        yy = np.append(y1, y2, axis=0)
        data = np.append(XX, yy, axis=1)

        f = h5py.File('traindata0.h5', 'w')
        f['trainXy'] = data
        f['sample'] = sample
        f.close()

        return data