import numpy as np
from MathCalculation3 import Mathcalculation3
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

font = font_manager.FontProperties(fname = 'C:/Windows/fonts/timesi.ttf')
font0 = font_manager.FontProperties(fname = 'C:/Windows/fonts/simkai.ttf')

def draw(x, y1, y11, y2, y22):
    plt.rcParams['font.family'] = 'Times New Roman'
    # 绘制 y1 和 y11，使用不同的颜色和线型
    plt.plot(x, y1, label='y$_{1}$', color='blue', linestyle='-')
    plt.plot(x, y11, label='y$_{1}$-MIF', color='blue', linestyle='--')

    # 绘制 y2 和 y22，使用不同的颜色和线型
    plt.plot(x, y2, label='y$_{2}$', color='red', linestyle='-')
    plt.plot(x, y22, label='y$_{2}$-MIF', color='red', linestyle='--')

    # 添加图例
    plt.legend(loc='upper left')
    plt.legend(prop={'family': 'Times New Roman', 'size': 12})

    # 添加标题和轴标签
    # plt.title('Overlapping Curves Example')
    plt.xlabel('x$_{1}$', fontsize=12, fontproperties=font)
    plt.ylabel('y', fontsize=12, fontproperties=font)

    # 旋转 x 轴的刻度标签，避免它们重叠
    plt.tick_params(axis='x', rotation=45)

    # 显示网格
    plt.grid(True)

    # 调整子图间距
    plt.tight_layout()

    # 显示图形
    plt.show()

# x1 = np.linspace(0, 1, 100)
# xx = np.ones((100, 4))
# xx[:, 0] = x1.T
#
# input_dim = 4
# mathcall = Mathcalculation3(input_dim)
# y1 = mathcall.multical(xx, 0)
# y2 = mathcall.multical(xx, 1)
#
# draw(x1, y1, y1, y2, y2)