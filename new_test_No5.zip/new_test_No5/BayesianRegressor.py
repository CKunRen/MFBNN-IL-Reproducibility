import torch
from torch import nn, optim
import torch.nn.functional as F
from blitz.modules import BayesianLinear
from blitz.utils import variational_estimator
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

@variational_estimator
class BayesianRegressor(nn.Module):
    def __init__(self, input_dim, output_dim, num_layers, m):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.num_layers = num_layers
        self.num_Neurons = m
        self.stats = True

        self.n = num_layers
        self.layer = nn.Sequential()
        self.layer.add_module('input', nn.Linear(input_dim, m))
        self.layer.add_module('Relu', nn.ReLU())
        self.layer.add_module('BN', nn.BatchNorm1d(m))
        for i in range(self.n):
            self.layer.add_module('hiden' + str(int(i)), nn.Linear(m, m))
            self.layer.add_module('Relu' + str(int(i)), nn.ReLU())
            if i != self.n - 1:
                self.layer.add_module('BN' + str(int(i)), nn.BatchNorm1d(m))
        # self.layer.add_module('output', nn.Linear(m, output_dim))
        self.layer.add_module('output', BayesianLinear(m, output_dim))

    def forward(self, x):
        x = self.layer(x)
        return x

    def evaluate_regression(self, X, samples=50):
        self.eval()
        preds = [self(X) for i in range(samples)]
        preds = torch.stack(preds)
        means = preds.mean(axis=0).cpu().detach().numpy()
        stds = preds.std(axis=0).cpu().detach().numpy()
        return means, stds

class BayesianRegressor2(nn.Module):
    def __init__(self, input_dim, output_dim, num_layers, m):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.num_layers = num_layers
        self.num_Neurons = m
        self.stats = True
        self.n = num_layers

        self.layer = nn.Sequential()
        self.layer.add_module('input', nn.Linear(input_dim + output_dim, m))
        self.layer.add_module('Relu', nn.SiLU())
        self.layer.add_module('BN', nn.BatchNorm1d(m))
        for i in range(self.n):
            self.layer.add_module('hiden' + str(int(i)), nn.Linear(m, m))
            self.layer.add_module('Relu' + str(int(i)), nn.ReLU())
            if i != self.n - 1:
                self.layer.add_module('BN' + str(int(i)), nn.BatchNorm1d(m))
        # self.layer2 = nn.Sequential()
        # self.layer2.add_module('output', nn.Linear(m + output_dim, output_dim))
        # self.layer2.add_module('output', BayesianLinear(m + output_dim, output_dim))
        self.layer.add_module('output', BayesianLinear(m, output_dim))

        self.attention1 = nn.Sequential()
        self.attention1.add_module('input', nn.Linear(input_dim, input_dim))
        self.attention1.add_module('Relu', nn.SiLU())

        self.attention2 = nn.Sequential()
        self.attention2.add_module('input', nn.Linear(output_dim, output_dim))
        self.attention2.add_module('Relu', nn.ReLU())

    def forward(self, x, y):
        y = torch.tensor(y).float().to(device)
        x1 = self.attention1(x)
        x = x * x1
        x = torch.cat([x, y], 1)
        x = self.layer(x)
        return x

    def evaluate_regression(self, X, y, samples=50):
        self.eval()
        preds = [self(X, y) for i in range(samples)]
        preds = torch.stack(preds)
        means = preds.mean(axis=0).cpu().detach().numpy()
        stds = preds.std(axis=0).cpu().detach().numpy()
        return means, stds