import torch
import numpy as np
import random
from sklearn.metrics import mean_squared_error
from matplotlib import font_manager
from Metal2lLearner import Metal2lLearner
from MathCalculation3 import Mathcalculation3
from test import draw
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib import font_manager


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
font = font_manager.FontProperties(fname = 'C:/Windows/fonts/timesi.ttf')
font0 = font_manager.FontProperties(fname = 'C:/Windows/fonts/simkai.ttf')


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def main():
    seeds = random.randint(0, 2000)
    print('random seed is ', seeds)
    global_lays1, global_lays2 = 1, 1
    global_ner1, global_ner2 = 5, 5
    setup_seed(seeds)
    markers = ['^', 's', 'p']
    input_dim = 1
    mathcall = Mathcalculation3(input_dim)
    metalearn = Metal2lLearner(input_dim, global_lays1, global_ner2, global_lays2, global_ner2).to(device)
    all_rmse = []
    load_path = []
    initial_sample = np.array([10, 4])
    x1 = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    x1 = x1.reshape(x1.shape[0], 1)
    y1 = mathcall.multical(x1, 0)
    x2 = np.array([0, 0.4, 0.8, 1.0])
    x2 = x2.reshape(x2.shape[0], 1)
    y2 = mathcall.multical(x2, 1)
    data1 = np.append(x1, y1, axis=1)
    data2 = np.append(x2, y2, axis=1)
    data = np.append(data1, data2, axis=0)
    x_valid = np.linspace(0, 1, 100)
    x_valid = x_valid.reshape(x_valid.shape[0], 1)
    y_valid = mathcall.multical(x_valid, 1)
    # y_valid1 = mathcall.multical(x_valid, 0)
    #
    # plt.plot(x_valid, y_valid1, label='y$_{1}$', color='blue', linestyle='-')
    # plt.plot(x_valid, y_valid, label='y$_{2}$', color='red', linestyle='-')
    # plt.legend(loc='upper left')
    # plt.legend(prop={'family': 'Times New Roman', 'size': 12})
    # plt.xlabel('x$_{1}$', fontsize=12, fontproperties=font)
    # plt.ylabel('y', fontsize=12, fontproperties=font)
    # plt.tick_params(axis='x', rotation=45)
    # plt.grid(True)
    # plt.tight_layout()
    # plt.show()
    for i in range(2):
        train_data, valid_data = mathcall.Mextract(data, initial_sample, i)
        # print(np.mean(train_data[:, -1]))
        if i == 1:
            iteration_error, all_error = metalearn.forward2(train_data, valid_data)
            x, all_error = metalearn.hftrain(train_data)
        else:
            iteration_error, all_error = metalearn(train_data, valid_data)
            _ = metalearn.temptrain(train_data)

    out1, _ = metalearn.model.evaluate_regression(torch.tensor(x_valid).float().to(device))
    pre_valid = metalearn.model2.evaluate_regression(torch.tensor(x_valid).float().to(device), out1)

    l2e = np.sqrt(np.sum((pre_valid - y_valid)**2)/np.sum(y_valid**2))

    # print('l2 error is %s' % (l2e))
    return l2e

if __name__ == '__main__':
    num = 10
    all_l2e = np.zeros(num)
    for i in range(num):
        all_l2e[i] = main()
    print('L2 error mean is %s and std is %s' % (np.mean(all_l2e), np.std(all_l2e)))

