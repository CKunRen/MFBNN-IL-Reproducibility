import numpy as np
import h5py
import math
import scipy.io

class Mathcalculation2():
    def __init__(self, input_dim):
        # self.low = -5
        # self.up = 10
        self.dim = input_dim
        self.odim = 1
        self.miu = 10
        self.sigma = 1

    def __call__(self, sample):
        input_data = self.getiput(sample)
        output_data = np.zeros([np.sum(sample), self.odim])
        for i in range(sample.shape[0]):
            # print(np.sum(sample[:i]))
            x = input_data[np.sum(sample[:i]):np.sum(sample[:i+1]),:]
            output_data[np.sum(sample[:i]):np.sum(sample[:i+1]), :] = self.getoutput(x, i)
        data = np.append(input_data, output_data, axis=1)
        f = h5py.File('traindata.h5', 'w')
        f['trainXy'] = data
        f['sample'] = sample
        f.close()
        scipy.io.savemat('data.mat', {'trainXy': data, 'sample': sample})
        return data

    def check_HL(self, count):
        x = self.getiput(count)
        y1 = self.multical(x, 0)
        y2 = self.multical(x, 1)
        y3 = self.multical(x, 2)
        y4 = self.multical(x, 3)
        return y1, y2, y3, y4

    def UQ(self, count):
        x = self.getiput(count)
        y = self.multical(x, 3)
        return x, y

    def getiput(self, sample):
        sample = np.sum(sample)
        x = np.zeros([sample, self.dim])
        for i in range(self.dim):
            # xx = np.random.uniform(self.low, self.up, size=(np.sum(sample)))
            xx = np.random.randn(np.sum(sample)) * self.sigma + self.miu
            x[:, i] = xx
        return x
        # return np.random.randn(np.sum(sample), self.dim) * self.sigma + self.miu
        # return np.random.uniform(self.low, self.up, size=(np.sum(sample), self.dim))

    def getoutput(self, data, flag):
        return self.multical(data, flag)

    def valid(self, count):
        x_val = self.getiput(count)
        y_val = self.multical(x_val, 3)
        data = np.append(x_val, y_val, axis=1)
        return data, x_val, y_val

    def Mextract(self, data, sample, i):
        index = int(sample[i])
        if round(index / 5) <= 1:
            valid_num = 2
        else:
            valid_num = round(index / 5) * 2
        allindex = 0
        for ss in range(i + 1):
            allindex += int(sample[ss])
        data_train = data[allindex - index:allindex, :]
        np.random.shuffle(data_train)
        data_valid = data_train[0:valid_num, :]
        return data_train, data_valid

    def extract(self, data, sample):
        np.random.shuffle(data)
        index = int(np.sum(sample))
        if round(index / 10) <= 1:
            valid_num = 2
        else:
            valid_num = round(index / 10)
        data_train = data[valid_num:, :]
        data_valid = data[:valid_num, :]
        return data_train, data_valid

    def multical(self, xx, flag):
        dim = xx.shape[1]
        count = xx.shape[0]
        y = np.zeros([count, 1])
        if flag == 0:
            for i in range(count):
                x = xx[i, :]
                y1, y2, y3 = 0, 0, 0
                for j in range(dim):
                    y1 += 0.1*x[j]**2
                    y2 += 0.2*j*x[j]
                    y3 += 0.3*j*x[j]
                # y[i] = y1 + y2**2 + y3**4
                y[i] = y1 + y2 + y3
        elif flag == 1:
            for i in range(count):
                x = xx[i, :]
                y1, y2, y3 = 0, 0, 0
                for j in range(dim):
                    y1 += 0.2*x[j]**2
                    y2 += 0.3*j*x[j]
                    y3 += 0.4*j*x[j]
                # y[i] = y1 + y2**2 + y3**4
                y[i] = y1 + y2 + y3
        elif flag == 2:
            for i in range(count):
                x = xx[i, :]
                y1, y2, y3 = 0, 0, 0
                for j in range(dim):
                    y1 += 0.1*x[j]**2
                    y2 += 0.1*j*x[j]
                    y3 += 0.2*j*x[j]
                # y[i] = y1 + y2**2 + y3**4
                y[i] = y1 + y2 + y3
        elif flag == 3:
            for i in range(count):
                x = xx[i, :]
                y1, y2 = 0, 0
                for j in range(dim):
                    y1 += 0.1*x[j]**2
                    y2 += 0.05*j*x[j]
                # y[i] = y1 + y2**2 + y2**4
                y[i] = y1 + y2 + y2
        return y