import torch
import numpy as np
import learn2learn as l2l
from tqdm import tqdm
from torch import nn, optim
import torch.nn.functional as F
import gc
from BayesianRegressor import BayesianRegressor, BayesianRegressor2

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class Metal2lLearner(nn.Module):
    def __init__(self, input_dim, num_layers1, num_Neurons1, num_layers2, num_Neurons2):
        super().__init__()
        self.save_path1 = './metamodel/maml0.pth'
        self.save_path2 = './metamodel/maml1.pth'
        self.temp_save_path = './metamodel/temp_maml.pth'
        self.maml_lr = 0.005
        self.lr = 0.005
        # self.task_num = 20
        self.train_times = 5
        self.epoch = 10
        self.input_dim = input_dim
        self.output_dim = 1
        self.iterations = 200
        self.hiter = 3000

        # self.num_layers = num_layers
        # self.num_Neurons = num_Neurons
        self.Flag = True

        self.model = BayesianRegressor(self.input_dim, self.output_dim, num_layers1, num_Neurons1)
        self.model2 = BayesianRegressor2(self.input_dim, self.output_dim, num_layers2, num_Neurons2)
        self.criterion = torch.nn.MSELoss()
        self.opt = optim.Adam(self.model.parameters(), lr=self.lr)

    def forward(self, train_data, valid_data):
        all_error = []
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model.to(device)
        meta_model = l2l.algorithms.MAML(self.model, lr=self.maml_lr)
        opt = optim.Adam(meta_model.parameters(), lr=self.lr)
        loss_func = torch.nn.MSELoss()

        tqdm_bar = tqdm(range(self.iterations))

        accs = []
        for iteration in tqdm_bar:
            iteration_error = 0.0
            iteration_acc = 0.0
            for _ in range(self.epoch):
                learner = meta_model.clone()
                train_task, valid_task = self.extract(train_data, 0), self.extract(valid_data, 1)

                # Fast Adaptation
                for step in range(self.train_times):
                    train_error, _ = self.compute_loss(train_task, device, learner, loss_func)
                    learner.adapt(train_error, allow_unused=True)

                # Compute validation loss
                valid_error, valid_acc = self.compute_loss(valid_task, device, learner, loss_func)
                iteration_error += valid_error
                iteration_acc += valid_acc
                del learner
                gc.collect()

            iteration_error /= self.epoch
            iteration_acc /= self.epoch
            tqdm_bar.set_description("Loss : {:.3f}".format(iteration_error.item()))
            accs.append(iteration_acc)
            # Take the meta-learning step
            opt.zero_grad()
            iteration_error.backward()
            opt.step()
            all_error.append(iteration_error)
        torch.save(self.model.state_dict(), self.save_path1)
        return iteration_error, all_error

    def forward2(self, train_data, valid_data):
        all_error = []
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model2.to(device)
        meta_model = l2l.algorithms.MAML(self.model2, lr=self.maml_lr)
        opt = optim.Adam(meta_model.parameters(), lr=self.lr)
        loss_func = torch.nn.MSELoss()

        tqdm_bar = tqdm(range(self.iterations))

        accs = []
        for iteration in tqdm_bar:
            iteration_error = 0.0
            iteration_acc = 0.0
            for _ in range(self.epoch):
                learner = meta_model.clone()
                train_task, valid_task = self.extract(train_data, 0), self.extract(valid_data, 1)

                # Fast Adaptation
                for step in range(self.train_times):
                    train_error, _ = self.compute_loss2(train_task, device, learner, loss_func)
                    learner.adapt(train_error, allow_unused=True)

                # Compute validation loss
                valid_error, valid_acc = self.compute_loss2(valid_task, device, learner, loss_func)
                iteration_error += valid_error
                iteration_acc += valid_acc
                del learner
                gc.collect()

            iteration_error /= self.epoch
            iteration_acc /= self.epoch
            tqdm_bar.set_description("Loss : {:.3f}".format(iteration_error.item()))
            accs.append(iteration_acc)
            # Take the meta-learning step
            opt.zero_grad()
            iteration_error.backward()
            opt.step()
            all_error.append(iteration_error)
        # self.save_path = './metamodel/maml' + str(self.co) + '.pth'
        torch.save(self.model2.state_dict(), self.save_path2)
        return iteration_error, all_error

    def extract(self, data, flag):
        count = data.shape[0]
        if flag == 0:
            task_num = round(count/5) * 2
        elif flag == 1:
            task_num = count
        np.random.shuffle(data)
        x_data = data[0:task_num, 0:self.input_dim]
        y_data = data[0:task_num, -1].reshape(task_num, 1)
        ds_data = torch.utils.data.TensorDataset(torch.tensor(x_data).float(), torch.tensor(y_data).float())
        loader_data = torch.utils.data.DataLoader(ds_data, batch_size=task_num, shuffle=True)
        return loader_data

    def compute_loss(self, task, device, learner, loss_func):
        loss = 0.0
        acc = 0.0
        for i, (x, y) in enumerate(task):
            # Moving to device
            x, y = x.to(device), y.to(device)
            output = learner(x)
            # curr_loss = F.l1_loss(output, y)
            curr_loss = loss_func(output, y)
            acc += self.accuracy(output, y)
            loss += curr_loss / len(task)
        loss /= len(task)
        return loss, acc

    def compute_loss2(self, task, device, learner, loss_func):
        loss = 0.0
        acc = 0.0
        for i, (x, y) in enumerate(task):
            # Moving to device
            x, y = x.to(device), y.to(device)
            y1 = self.model(x)
            output = learner(x, y1)
            # curr_loss = F.l1_loss(output, y)
            curr_loss = loss_func(output, y)
            acc += self.accuracy(output, y)
            loss += curr_loss / len(task)
        loss /= len(task)
        return loss, acc

    def accuracy(self, predictions, targets):
        predictions = predictions.argmax(dim=1)
        acc = (predictions == targets).sum().float()
        acc /= len(targets)
        return acc.item()

    def hftrain(self, train_data):
        xt = train_data[:, 0:self.input_dim]
        yt = train_data[:, -1].reshape(xt.shape[0], 1)
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model2.load_state_dict(torch.load(self.save_path2))
        self.model2.to(device)
        ds_data = torch.utils.data.TensorDataset(torch.tensor(xt).float().to(device),
                                                 torch.tensor(yt).float().to(device))
        if (xt.shape[0] % 2) != 0:
            task_num = xt.shape[0] + 1
        else:
            task_num = xt.shape[0]
        loader_data = torch.utils.data.DataLoader(ds_data, batch_size=round(task_num / 2), shuffle=True)
        opt = optim.Adam(self.model2.parameters(), lr=0.05)
        scheduler = torch.optim.lr_scheduler.StepLR(opt, step_size=100, gamma=0.5)
        loss_func = torch.nn.MSELoss()
        tqdm_bar = tqdm(range(self.hiter))
        min_error = 100000000
        all_error = []
        for _ in tqdm_bar:
            for i, (datapoints, labels) in enumerate(loader_data):
                out1 = self.model(datapoints)
                out = self.model2(datapoints, out1)
                loss = loss_func(out, labels)

                # loss = self.model.sample_elbo(inputs=datapoints,
                #                          labels=labels,
                #                          criterion=loss_func,
                #                          sample_nbr=3, complexity_cost_weight=1 / len(loader_data))
                opt.zero_grad()
                loss.backward()
                opt.step()
                scheduler.step()
            tqdm_bar.set_description("Loss : {:.3f}".format(loss.item()))
            all_error.append(loss)
            if loss.item() < min_error:
                min_error = loss.item()
                torch.save(self.model2.state_dict(), self.save_path2)
        x = np.arange(self.hiter)
        return x, all_error

    def temptrain(self, train_data):
        xt = train_data[:, 0:self.input_dim]
        yt = train_data[:, -1].reshape(xt.shape[0], 1)
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model.load_state_dict(torch.load(self.save_path1))
        self.model.to(device)
        ds_data = torch.utils.data.TensorDataset(torch.tensor(xt).float().to(device),
                                                 torch.tensor(yt).float().to(device))
        if (xt.shape[0] % 2) != 0:
            task_num = xt.shape[0] + 1
        else:
            task_num = xt.shape[0]
        loader_data = torch.utils.data.DataLoader(ds_data, batch_size=round(task_num / 2), shuffle=True)
        opt = optim.Adam(self.model.parameters(), lr=0.05)
        scheduler = torch.optim.lr_scheduler.StepLR(opt, step_size=100, gamma=0.5)
        loss_func = torch.nn.MSELoss()
        tqdm_bar = tqdm(range(self.hiter))
        min_error = 10000000
        all_error = []
        for _ in tqdm_bar:
            for i, (datapoints, labels) in enumerate(loader_data):
                out = self.model(datapoints)
                loss = loss_func(out, labels)
                # loss = F.l1_loss(out, labels)
                # loss = self.model.sample_elbo(inputs=datapoints,
                #                          labels=labels,
                #                          criterion=loss_func,
                #                          sample_nbr=3, complexity_cost_weight=1 / len(loader_data))
                opt.zero_grad()
                loss.backward()
                opt.step()
                scheduler.step()
            tqdm_bar.set_description("Loss : {:.3f}".format(loss.item()))
            all_error.append(loss)
            if loss.item() < min_error:
                min_error = loss.item()
                torch.save(self.model.state_dict(), self.save_path1)
        x = np.arange(self.hiter)
        return x, all_error
